/**
 * 
 */
/**
 * 
 */
module train {
	requires java.desktop;
}