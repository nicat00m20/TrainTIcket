//package Login_SignUp;
//import java.sql.*;
//
//public class DbConnection {
//    public static void main(String[] args) {
//        try {
//            // Establish database connection
//            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "username", "password");
//
//            // Query to check user credentials
//            String query = "SELECT * FROM users WHERE username=? AND password=?";
//            PreparedStatement statement = connection.prepareStatement(query);
//            statement.setString(1, usernameTextField.getText());
//            statement.setString(2, passwordTextField.getText());
//            ResultSet resultSet = statement.executeQuery();
//
//            // Check if user exists
//            if (resultSet.next()) {
//                // User authenticated, proceed with login
//                System.out.println("Login successful");
//            } else {
//                // Invalid credentials
//                System.out.println("Invalid username or password");
//            }
//
//            // Close resources
//            resultSet.close();
//            statement.close();
//            connection.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//}
package Login;


